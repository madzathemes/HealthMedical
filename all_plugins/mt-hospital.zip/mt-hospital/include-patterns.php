<?php

/* Author: Madars Bitenieks */

$l1 = '/images/patterns/';
$l2 = get_template_directory_uri().'/images/patterns/';

$patterns = array(
	array(
		'value'   => 'off',
		'label'   => 'none',
		'src'     => get_template_directory_uri().'/images/patterns/patterns-none.jpg'
	),
	array( 	'value' => $l1.'60degree_gray.png', 'label' => '60degree_gray', 'src' => $l2.'60degree_gray.png' ),
	array( 	'value' => $l1.'agsquare.png', 'label' => 'agsquare', 'src' => $l2.'agsquare.png' ),
	array( 	'value' => $l1.'back_pattern.png', 'label' => 'back_pattern', 'src' => $l2.'back_pattern.png' ),
	array( 	'value' => $l1.'bright_squares.png', 'label' => 'bright_squares', 'src' => $l2.'bright_squares.png' ),
	array( 	'value' => $l1.'brushed_alu_dark.png', 'label' => 'brushed_alu_dark', 'src' => $l2.'brushed_alu_dark.png' ),
	array( 	'value' => $l1.'brushed_alu.png', 'label' => 'brushed_alu', 'src' => $l2.'brushed_alu.png' ),
	array( 	'value' => $l1.'carbon_fibre.png', 'label' => 'carbon_fibre', 'src' => $l2.'carbon_fibre.png' ),
	array( 	'value' => $l1.'cartographer.png', 'label' => 'cartographer', 'src' => $l2.'cartographer.png' ),
	array( 	'value' => $l1.'cloth_alike.png', 'label' => 'cloth_alike', 'src' => $l2.'cloth_alike.png' ),
	array( 	'value' => $l1.'crisp_paper_ruffles.png', 'label' => 'crisp_paper_ruffles', 'src' => $l2.'crisp_paper_ruffles.png' ),
	array( 	'value' => $l1.'crissXcross.png', 'label' => 'crissXcross', 'src' => $l2.'crissXcross.png' ),
	array( 	'value' => $l1.'dark_brick_wall.png', 'label' => 'dark_brick_wall', 'src' => $l2.'dark_brick_wall.png' ),
	array( 	'value' => $l1.'dark_exa.png', 'label' => 'dark_exa', 'src' => $l2.'dark_exa.png' ),
	array( 	'value' => $l1.'dark_wall.png', 'label' => 'dark_wall', 'src' => $l2.'dark_wall.png' ),
	array( 	'value' => $l1.'dark_wood.png', 'label' => 'dark_wood', 'src' => $l2.'dark_wood.png' ),
	array( 	'value' => $l1.'diagmonds.png', 'label' => 'diagmonds', 'src' => $l2.'diagmonds.png' ),
	array( 	'value' => $l1.'fabric_of_squares_gray.png', 'label' => 'fabric_of_squares_gray', 'src' => $l2.'fabric_of_squares_gray.png' ),
	array( 	'value' => $l1.'gplaypattern.png', 'label' => 'gplaypattern', 'src' => $l2.'gplaypattern.png' ),
	array( 	'value' => $l1.'green_dust_scratch.png', 'label' => 'green_dust_scratch', 'src' => $l2.'green_dust_scratch.png' ),
	array( 	'value' => $l1.'green_gobbler.png', 'label' => 'green_gobbler', 'src' => $l2.'green_gobbler.png' ),
	array( 	'value' => $l1.'grey_sandbag.png', 'label' => 'grey_sandbag', 'src' => $l2.'grey_sandbag.png' ),
	array( 	'value' => $l1.'grey.png', 'label' => 'grey', 'src' => $l2.'grey.png' ),
	array( 	'value' => $l1.'greyzz.png', 'label' => 'greyzz', 'src' => $l2.'greyzz.png' ),
	array( 	'value' => $l1.'grunge_wall.png', 'label' => 'grunge_wall', 'src' => $l2.'grunge_wall.png' ),
	array( 	'value' => $l1.'hexellence.png', 'label' => 'hexellence', 'src' => $l2.'hexellence.png' ),
	array( 	'value' => $l1.'husk.png', 'label' => 'husk', 'src' => $l2.'husk.png' ),
	array( 	'value' => $l1.'inflicted.png', 'label' => 'inflicted', 'src' => $l2.'inflicted.png' ),
	array( 	'value' => $l1.'irongrip.png', 'label' => 'irongrip', 'src' => $l2.'irongrip.png' ),
	array( 	'value' => $l1.'kindajean.png', 'label' => 'kindajean', 'src' => $l2.'kindajean.png' ),
	array( 	'value' => $l1.'large_leather.png', 'label' => 'large_leather', 'src' => $l2.'large_leather.png' ),	
	array( 	'value' => $l1.'lghtmesh.png', 'label' => 'lghtmesh', 'src' => $l2.'lghtmesh.png' ),
	array( 	'value' => $l1.'light_alu.png', 'label' => 'light_alu', 'src' => $l2.'light_alu.png' ),
	array( 	'value' => $l1.'light_honeycomb.png', 'label' => 'light_honeycomb', 'src' => $l2.'light_honeycomb.png' ),
	array( 	'value' => $l1.'light_wool.png', 'label' => 'light_wool', 'src' => $l2.'light_wool.png' ),
	array( 	'value' => $l1.'lightpaperfibers.png', 'label' => 'lightpaperfibers', 'src' => $l2.'lightpaperfibers.png' ),
	array( 	'value' => $l1.'mirrored_squares.png', 'label' => 'mirrored_squares', 'src' => $l2.'mirrored_squares.png' ),
	array( 	'value' => $l1.'notebook.png', 'label' => 'notebook', 'src' => $l2.'notebook.png' ),
	array( 	'value' => $l1.'old_mathematics.png', 'label' => 'old_mathematics', 'src' => $l2.'old_mathematics.png' ),
	array( 	'value' => $l1.'old_wall.png', 'label' => 'old_wall', 'src' => $l2.'old_wall.png' ),
	array( 	'value' => $l1.'p5.png', 'label' => 'p5', 'src' => $l2.'p5.png' ),
	array( 	'value' => $l1.'perforated_white_leather.png', 'label' => 'perforated_white_leather', 'src' => $l2.'perforated_white_leather.png' ),
	array( 	'value' => $l1.'pinstriped_suit.png', 'label' => 'pinstriped_suit', 'src' => $l2.'pinstriped_suit.png' ),
	array( 	'value' => $l1.'purty_wood.png', 'label' => 'purty_wood', 'src' => $l2.'purty_wood.png' ),
	array( 	'value' => $l1.'px_by_Gre3g.png', 'label' => 'px_by_Gre3g', 'src' => $l2.'px_by_Gre3g.png' ),
	array( 	'value' => $l1.'redox_01.png', 'label' => 'redox_01', 'src' => $l2.'redox_01.png' ),
	array( 	'value' => $l1.'redox_02.png', 'label' => 'redox_02', 'src' => $l2.'redox_02.png' ),
	array( 	'value' => $l1.'retina_wood.png', 'label' => 'retina_wood', 'src' => $l2.'retina_wood.png' ),
	array( 	'value' => $l1.'robots.png', 'label' => 'robots', 'src' => $l2.'robots.png' ),
	array( 	'value' => $l1.'sneaker_mesh_fabric.png', 'label' => 'sneaker_mesh_fabric', 'src' => $l2.'sneaker_mesh_fabric.png' ),
	array( 	'value' => $l1.'squares.png', 'label' => 'squares', 'src' => $l2.'squares.png' ),
	array( 	'value' => $l1.'tasky_pattern.png', 'label' => 'tasky_pattern', 'src' => $l2.'tasky_pattern.png' ),
	array( 	'value' => $l1.'textured_stripes.png', 'label' => 'textured_stripes', 'src' => $l2.'textured_stripes.png' ),
	array( 	'value' => $l1.'tileable_wood_texture.png', 'label' => 'tileable_wood_texture', 'src' => $l2.'tileable_wood_texture.png' ),
	array( 	'value' => $l1.'tree_bark.png', 'label' => 'tree_bark', 'src' => $l2.'tree_bark.png' ),
	array( 	'value' => $l1.'type.png', 'label' => 'type', 'src' => $l2.'type.png' ),
	array( 	'value' => $l1.'vintage_speckles.png', 'label' => 'vintage_speckles', 'src' => $l2.'vintage_speckles.png' ),
	array( 	'value' => $l1.'wall4.png', 'label' => 'wall4', 'src' => $l2.'wall4.png' ),
	array( 	'value' => $l1.'white_brick_wall.png', 'label' => 'white_brick_wall', 'src' => $l2.'white_brick_wall.png' ),
	array( 	'value' => $l1.'white_tiles.png', 'label' => 'white_tiles', 'src' => $l2.'white_tiles.png' ),
	array( 	'value' => $l1.'white_wall_hash.png', 'label' => 'white_wall_hash', 'src' => $l2.'white_wall_hash.png' ),
	array( 	'value' => $l1.'wild_flowers.png', 'label' => 'wild_flowers', 'src' => $l2.'wild_flowers.png' ),
	array( 	'value' => $l1.'wood_1.png', 'label' => 'wood_1', 'src' => $l2.'wood_1.png' ),
	array( 	'value' => $l1.'wood_pattern.png', 'label' => 'wood_pattern', 'src' => $l2.'wood_pattern.png' ),
	array( 	'value' => $l1.'worn_dots.png', 'label' => 'worn_dots', 'src' => $l2.'worn_dots.png' ),
	array( 	'value' => $l1.'xv.png', 'label' => 'xv', 'src' => $l2.'xv.png' ),
	array(
		'value'   => '/images/patterns/medicaldoctor.jpg',
		'label'   => 'medicaldoctor',
		'src'     => get_template_directory_uri().'/images/patterns/medicaldoctor.jpg'
	),
	array(
		'value'   => '/images/patterns/brickwall.png',
		'label'   => 'brickwall',
		'src'     => get_template_directory_uri().'/images/patterns/brickwall.png'
	),
	array(
		'value'   => '/images/patterns/escheresque_ste.png',
		'label'   => 'escheresque_ste',
		'src'     => get_template_directory_uri().'/images/patterns/escheresque_ste.png'
	),
	array(
		'value'   => '/images/patterns/wild_oliva.png',
		'label'   => 'wild_oliva',
		'src'     => get_template_directory_uri().'/images/patterns/wild_oliva.png'
	),
	array(
		'value'   => '/images/patterns/noisy_grid.png',
		'label'   => 'noisy_grid',
		'src'     => get_template_directory_uri().'/images/patterns/noisy_grid.png'
	),
	array(
		'value'   => '/images/patterns/skelatal_weave.png',
		'label'   => 'brickwall',
		'src'     => get_template_directory_uri().'/images/patterns/skelatal_weave.png'
	),
	array(
		'value'   => '/images/patterns/greyfloral.png',
		'label'   => 'greyfloral',
		'src'     => get_template_directory_uri().'/images/patterns/greyfloral.png'
	)    
);			